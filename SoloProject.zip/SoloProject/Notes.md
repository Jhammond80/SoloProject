Use the Flowbite popover for display of Goal and possably thought entry
Sample popovers --- in the home page amd see if we can make them for each journal enty and goal entry

