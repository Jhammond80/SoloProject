// import React from 'react';
// import PinKeypad from '../components/PinKeyPad';

// const PinLogin = () =>{
//   const handlePinSubmit = (pin) => {
//     console.log('Submitted PIN:', pin);
//     // Handle PIN submission (e.g., validate and send to backend)
//   };

//   return (
//     <div>
//       <h1>Create Header</h1>
//       <PinKeypad onComplete={handlePinSubmit} />
//     </div>
//   );
// }

// export default PinLogin;
