// import axios from 'axios';

// const http = axios.create({
//     baseURL: 'http://localhost:8000/api'
// });

// function loginUser(email, pin) {
//     return http.post('/login', { email, pin })
//         .then(res => res.data)
//         .catch(err => {
//             throw err;
//         });
// }

// export { loginUser };
