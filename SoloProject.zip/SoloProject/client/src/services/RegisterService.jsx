// import axios from 'axios';

// const http = axios.create({
//     baseURL: 'http://localhost:8000/api'
// });

// function registerUser(username, email, pin) {
//     return http.post('/register', { username, email, pin })
//         .then(res => res.data)
//         .catch(err => {
//             throw err;
//         });
// }

// export { registerUser };
